/*global KeyboardJS:true*/  // Meteor.js creates a file-scope global for exporting. This comment prevents a potential JSHint warning.
KeyboardJS = window.KeyboardJS;
delete window.KeyboardJS;
